# OpenSymbolic ETHICS v0.1

## Principios
- Inclusión, transparencia y seguridad del usuario.
- Datos mínimos, sin PII por defecto.
- Uso responsable en educación, accesibilidad y HCI.

## Riesgos y mitigación
- **Sobrecarga sensorial**: límites de volumen, duración, frecuencia; opción de pausa inmediata.
- **Malinterpretación**: diccionario canónico y ejemplos; validación de comandos críticos.
- **Sesgos culturales**: revisión por comité plural; RFCs abiertos.

## Datos y privacidad
- Telemetría opcional y anónima.
- Logs locales por defecto; no enviar datos sin consentimiento.

## Publicación y crédito
- Licencia MIT; atribución al proyecto y autores.
- Resultados experimentales abiertos (preprints, datasets anonimizados).
