# OpenSymbolic THREAT_MODEL v0.1

## Alcance
Riesgos en interfaz y canal audio-visual para usuarios y sistemas conectados.

## Actores de amenaza
- Usuario malicioso local.
- Script externo que genere secuencias engañosas.
- Software que abuse de estímulos (audio/visual).

## Vectores
- Secuencias que ejecuten acciones no intencionadas.
- Estímulos audio-visual nocivos (volumen alto, flashes).
- Inyección de `.osym` malformado.

## Controles
- Confirmación explícita para acciones peligrosas.
- Límite de tasa (rate limiting) y volumen/frecuencia.
- Validación estricta de `.osym`; sandbox para reproducción.
- Principio de menor privilegio en permisos.

## Respuesta
- Botón de parada de emergencia.
- Registro de incidentes local y guía de reporte (SECURITY.md futuro).
