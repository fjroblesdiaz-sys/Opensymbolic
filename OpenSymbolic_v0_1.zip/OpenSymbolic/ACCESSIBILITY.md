# OpenSymbolic ACCESSIBILITY v0.1

## 1. Principios
- Canal **dual**: audio + visual obligatorios.
- Redundancia perceptual para usuarios con daltonismo o baja visión.
- Contraste mínimo **WCAG AA** para todos los tokens.

## 2. Paletas
- Usar variantes aptas para deuteranopia/protanopia/tritanopia.
- Patrón redundante por forma:
  - circle = borde punteado
  - square = borde sólido
  - triangle = lomo inferior grueso
  - hexagon = doble borde
- Texto/dígito visible junto al símbolo.

## 3. Audio
- Rango seguro: 200–2000 Hz; volumen limitado.
- Envelope suave para evitar fatiga y sobresalto.
- Alternativa vibro-táctil opcional en futuras versiones.

## 4. Interacción
- Navegable por teclado, foco visible, ARIA labels descriptivos.
- Modo “audio-only” y “visual-only” con advertencias: en v0.1 ambos deben coexistir para cumplir norma.

## 5. Documentación
- Guía de alto contraste, ejemplo de color sustituto (patrones) y atajos de teclado.
