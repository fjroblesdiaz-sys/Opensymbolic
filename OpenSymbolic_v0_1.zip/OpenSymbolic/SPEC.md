# OpenSymbolic SPEC v0.1

## 1. Arquitectura
- **Modelo dual audio-visual**: ambos canales son **obligatorios** en v0.1.
- **Token = (color, forma, número, tono)**.
- **Instrucción = secuencia de 3–5 tokens**. Traducción determinista a frase operativa.
- **Canal audio (MIDI)**: nota = color, octava = intensidad/número, timbre = forma.
- **Canal visual**: color HEX + forma geométrica + dígito visible.

## 2. Alfabeto base v0.1
- Colores: {red, green, blue, cyan, magenta, yellow, orange, white, black, gray}.
- Formas: {circle, square, triangle, hexagon}.
- Números: 0–9.
- Timbres recomendados: {sine, square, saw, triangle} mapeados a {circle, square, triangle, hexagon}.

## 3. Mapeos normativos
- **Color → Nota MIDI** (C mayor):
  - red=C4, green=E4, blue=G4, cyan=A4, magenta=B4,
  - yellow=C5, orange=D5, white=E5, black=F5, gray=G5.
- **Forma → Timbre**:
  - circle=sine, square=square, triangle=triangle, hexagon=saw.
- **Número → Octava/modificador**:
  - 0–9 mapea a octavas {3..6}: octava_base=4 y `octava = 3 + floor(n/3)`.

## 4. Sintaxis
- Secuencia mínima: 3 tokens; máxima recomendada: 5 tokens.
- Gramática: `(Color Forma Número){3..5}` → acción ejecutable.
- Desambiguación: ordenar por **verbo (color)** → **objeto (forma)** → **parámetro (número)**.

## 5. Semántica base (ejemplos)
- red circle 0 → “crear archivo 0”
- green triangle 1 → “abrir aplicación 1”
- blue square 2 → “guardar carpeta 2”
- yellow triangle 5 → “borrar aplicación 5”
- magenta circle 4 → “buscar archivo 4”

## 6. Codificación de archivo
- Formato `.osym` (JSON):
```json
{ "version":"0.1", "sequence":[{"color":"red","shape":"circle","number":0,"tone":"C4"}] }
```
- Validación: campos obligatorios y valores dentro del alfabeto v0.1.

## 7. API mínima
- `POST /translate/text-to-osym` → `.osym`
- `POST /translate/osym-to-text` → texto canónico
- `POST /render/audio` → MIDI/Audio
- `POST /render/visual` → SVG/Canvas

## 8. Compatibilidad y extensiones
- Extensiones futuras: canal háptico, nuevas formas/colores, frases compuestas.
- **Regla de estabilidad**: no romper mapeos v0.x; nuevas adiciones via `RFC-XX`.
