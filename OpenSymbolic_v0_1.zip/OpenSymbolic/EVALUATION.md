# OpenSymbolic EVALUATION v0.1

## Objetivo
Medir **comprensión**, **tiempo de aprendizaje** y **carga percibida** del sistema dual audio-visual.

## Diseño
- Participantes: n=20–30, multilingües.
- Tareas: 10 tokens aislados + 5 secuencias (3–5 tokens).
- Condiciones: entrenamiento 5 min, test 10–12 min.

## Métricas
- Exactitud semántica (% interpretaciones correctas).
- Tiempo por tarea (s).
- Aprendizaje: diferencia entre los 3 primeros y 3 últimos ítems.
- Carga subjetiva: NASA-TLX abreviado (esfuerzo, frustración, rendimiento).

## Criterios de éxito v0.1
- ≥80% de exactitud media en tokens.
- ≥70% en secuencias.
- Tiempo mediano <10 s por token y <25 s por secuencia tras entrenamiento.
- Carga subjetiva “baja–media”.

## Análisis
- Medias, desviaciones, IC95%.
- Curva de aprendizaje por bloque.
- Errores frecuentes para ajustar diccionario y mapeos.
