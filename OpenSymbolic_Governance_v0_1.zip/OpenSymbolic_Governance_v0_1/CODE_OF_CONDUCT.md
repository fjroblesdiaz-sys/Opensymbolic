# OpenSymbolic Code of Conduct

## 1. Purpose
The Code of Conduct establishes expectations for behavior and ensures a welcoming and professional environment for contributors and researchers.

## 2. Expected Behavior
- Demonstrate respect, integrity, and scientific honesty.
- Provide constructive feedback.
- Accept responsibility for one’s words and actions.
- Maintain confidentiality of sensitive information.

## 3. Unacceptable Behavior
- Harassment, discrimination, or exclusion of any kind.
- Unethical data manipulation or plagiarism.
- Aggressive or disruptive conduct in communications or code reviews.

## 4. Reporting and Enforcement
Incidents may be reported to the Project Lead or maintainers via official contact channels. 
Violations will be reviewed confidentially and may result in restriction of participation.

## 5. Attribution
This Code of Conduct is adapted from the Contributor Covenant v2.1.

---
Project Lead: **Francisco Javier — Soluciones Blockchain**
