# OpenSymbolic Governance Model

## 1. Structure
- **Project Lead**: Francisco Javier (Soluciones Blockchain).  
- **Core Maintainers**: senior contributors responsible for repository integrity.  
- **Contributors**: individuals or institutions submitting changes or research results.

## 2. Decision Process
- **Technical decisions**: made by consensus of maintainers; if unresolved, final decision by Project Lead.  
- **Normative changes**: must follow the RFC process (see `/rfc/`).  
- **Releases**: tagged and signed by the Project Lead or delegated maintainer.

## 3. Meetings and Communication
- Quarterly virtual meetings to review progress and research milestones.  
- Communication via GitHub Discussions and official mailing list.

## 4. Transparency
All decisions, RFCs, and meeting notes will be public within the repository.

---
Project Lead: **Francisco Javier — Soluciones Blockchain**
