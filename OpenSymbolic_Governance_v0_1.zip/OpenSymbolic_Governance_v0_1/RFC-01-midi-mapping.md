# RFC-01: MIDI Mapping Standardization

## Abstract
This RFC defines the initial normative mapping between color, shape, and MIDI parameters for OpenSymbolic v0.1.

## Rationale
To ensure interoperability and reproducibility, the color–shape–number combinations must map deterministically to audio events.

## Specification
| Color | MIDI Note | Shape | Timbre | Example Frequency (Hz) |
|-------|-----------|-------|--------|------------------------|
| Red | C4 | Circle | Sine | ~261.63 |
| Green | E4 | Triangle | Triangle | ~329.63 |
| Blue | G4 | Square | Square | ~392.00 |
| Cyan | A4 | Hexagon | Saw | ~440.00 |
| Magenta | B4 | Circle | Sine | ~493.88 |
| Yellow | C5 | Triangle | Triangle | ~523.25 |
| Orange | D5 | Square | Square | ~587.33 |
| White | E5 | Circle | Sine | ~659.25 |
| Black | F5 | Triangle | Triangle | ~698.46 |
| Gray | G5 | Hexagon | Saw | ~783.99 |

## Implementation Notes
- Octave modulation reflects numerical token value (0–9).  
- MIDI velocity encodes token emphasis or urgency.  
- All implementations must validate consistency with this mapping.

## Status
Accepted — normative for OpenSymbolic v0.1.

---
Project Lead: **Francisco Javier — Soluciones Blockchain**
