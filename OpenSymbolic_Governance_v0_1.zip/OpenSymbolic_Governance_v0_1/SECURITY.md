# OpenSymbolic Security Policy

## 1. Supported Versions
Security updates and advisories apply to the latest stable release and active branches.

## 2. Reporting a Vulnerability
To report security issues or potential misuse of audio-visual output:
1. Create a private security advisory via GitHub.  
2. Do not disclose publicly until verified and patched.  
3. Include details: system, version, reproduction steps, and expected impact.

## 3. Response Process
- Initial acknowledgment within 72 hours.  
- Verification and patch timeline within 14 days.  
- Public disclosure once fix is released.

## 4. Best Practices
- Validate `.osym` files before execution.  
- Limit volume and frequency to safe ranges.  
- Implement emergency stop functionality in all demos.

---
Project Lead: **Francisco Javier — Soluciones Blockchain**
