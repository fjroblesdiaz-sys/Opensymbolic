# Contributing to OpenSymbolic

## 1. Introduction
OpenSymbolic is an open research and engineering initiative led by Francisco Javier (Soluciones Blockchain). 
Contributions are welcomed from scientists, engineers, and practitioners across accessibility, AI, human–computer interaction, and multisensory communication.

## 2. Guiding Principles
- Scientific integrity and reproducibility.
- Transparency and open collaboration.
- Accessibility and inclusion by design.
- Respectful and professional communication.

## 3. How to Contribute
1. Fork the repository and create a new branch for your feature or fix.  
2. Follow the `SPEC.md` and RFC process for normative changes.  
3. Submit a pull request (PR) referencing related issues or RFCs.  
4. Include documentation, tests, and rationale for any modification.  
5. The Project Lead or maintainers will review and merge upon consensus.

## 4. Style Guidelines
- Use clear and concise English.
- Follow Markdown standards for documentation.
- Commit messages: short imperative form (e.g., “Add MIDI mapping validation”).

## 5. Intellectual Property
All contributions are licensed under the MIT License and remain open for academic and industrial use with attribution to the project.

---
Project Lead: **Francisco Javier — Soluciones Blockchain**
