const palette = document.getElementById('palette');
const sequence = document.getElementById('sequence');
const output = document.getElementById('output');
const runBtn = document.getElementById('runBtn');

async function loadTokens(){
  const res = await fetch('../tokens_base.osym');
  const data = await res.json();
  return data.tokens;
}

function colorToCSS(name){
  const map = {red:'#ef4444', green:'#22c55e', blue:'#3b82f6', cyan:'#06b6d4', magenta:'#d946ef', yellow:'#eab308', orange:'#f59e0b', white:'#e5e7eb', black:'#111827', gray:'#9ca3af'};
  return map[name] || '#64748b';
}

function createTokenEl(tok){
  const el = document.createElement('div');
  el.className = 'token';
  el.draggable = true;
  el.dataset.id = tok.id;
  el.dataset.color = tok.color;
  el.dataset.shape = tok.shape;
  el.dataset.number = tok.number;
  el.dataset.action = tok.action;
  el.dataset.tone = tok.tone;

  const shape = document.createElement('div');
  shape.className = `shape ${tok.shape}`;
  shape.style.color = colorToCSS(tok.color);
  shape.style.background = tok.shape==='triangle' ? 'none' : colorToCSS(tok.color);

  const label = document.createElement('div');
  label.textContent = `${tok.color} · ${tok.shape} · ${tok.number}`;

  const action = document.createElement('small');
  action.textContent = tok.action;

  el.appendChild(shape);
  el.appendChild(label);
  el.appendChild(action);

  el.addEventListener('dragstart', e=>{
    e.dataTransfer.setData('text/plain', JSON.stringify(tok));
  });

  return el;
}

function createSeqToken(tok){
  const el = document.createElement('div');
  el.className = 'seq-token';
  el.innerHTML = `<span>${tok.color}</span> <span>${tok.shape}</span> <strong>${tok.number}</strong>`;
  el.style.borderColor = colorToCSS(tok.color);
  return el;
}

function initDnD(){
  sequence.addEventListener('dragover', e=>{ e.preventDefault(); });
  sequence.addEventListener('drop', e=>{
    e.preventDefault();
    const data = JSON.parse(e.dataTransfer.getData('text/plain'));
    sequence.appendChild(createSeqToken(data));
    sequence.dataset.seq = (sequence.dataset.seq || '[]');
    const arr = JSON.parse(sequence.dataset.seq);
    arr.push(data);
    sequence.dataset.seq = JSON.stringify(arr);
  });
}

function runSequence(){
  const arr = JSON.parse(sequence.dataset.seq || '[]');
  if(arr.length === 0){
    output.textContent = 'Secuencia vacía.';
    return;
  }
  // Very simple "translation":
  const phrases = arr.map(t => {
    return `${t.action} ${t.shape} ${t.number}`;
  });
  output.textContent = '→ ' + phrases.join(' | ');
}

runBtn.addEventListener('click', runSequence);

(async()=>{
  const tokens = await loadTokens();
  tokens.forEach(t => palette.appendChild(createTokenEl(t)));
  initDnD();
})();
