// OpenSymbolic v3.0 - Communication App for Non-Verbal People
// With Voice Synthesis, Categories, and Accessibility Features

class AudioEngine {
    constructor() {
        this.audioContext = null;
        this.isPlaying = false;
    }

    init() {
        if (!this.audioContext) {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }
    }

    playTone(frequency, duration = 0.5, type = 'sine') {
        this.init();
        
        const oscillator = this.audioContext.createOscillator();
        const gainNode = this.audioContext.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(this.audioContext.destination);
        
        oscillator.type = type;
        oscillator.frequency.setValueAtTime(frequency, this.audioContext.currentTime);
        
        const now = this.audioContext.currentTime;
        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.linearRampToValueAtTime(0.4, now + 0.05);
        gainNode.gain.linearRampToValueAtTime(0.25, now + duration * 0.5);
        gainNode.gain.linearRampToValueAtTime(0, now + duration);
        
        oscillator.start(now);
        oscillator.stop(now + duration);
    }

    async playSequence(chain, onSymbolPlay) {
        if (chain.length === 0) return;
        
        this.isPlaying = true;
        
        for (let i = 0; i < chain.length; i++) {
            if (!this.isPlaying) break;
            
            const conceptron = chain[i];
            
            if (onSymbolPlay) {
                onSymbolPlay(conceptron, i);
            }
            
            this.playTone(conceptron.tone, 0.5);
            
            await new Promise(resolve => setTimeout(resolve, 650));
        }
        
        this.isPlaying = false;
    }

    async playScale() {
        this.init();
        const notes = [261, 293, 329, 349, 392, 440, 493, 523];
        
        for (const freq of notes) {
            this.playTone(freq, 0.2);
            await new Promise(resolve => setTimeout(resolve, 220));
        }
    }

    stop() {
        this.isPlaying = false;
    }
}

// Voice Synthesis Engine
class VoiceEngine {
    constructor() {
        this.synth = window.speechSynthesis;
        this.voices = [];
        this.selectedVoice = null;
        this.loadVoices();
    }

    loadVoices() {
        this.voices = this.synth.getVoices();
        if (this.voices.length === 0) {
            this.synth.onvoiceschanged = () => {
                this.voices = this.synth.getVoices();
                this.selectSpanishVoice();
            };
        } else {
            this.selectSpanishVoice();
        }
    }

    selectSpanishVoice() {
        const spanishVoices = this.voices.filter(v => v.lang.includes('es'));
        if (spanishVoices.length > 0) {
            this.selectedVoice = spanishVoices[0];
        } else {
            this.selectedVoice = this.voices[0];
        }
    }

    speak(text, rate = 0.9, pitch = 1) {
        this.synth.cancel();
        
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = this.selectedVoice;
        utterance.rate = rate;
        utterance.pitch = pitch;
        
        if (this.selectedVoice && this.selectedVoice.lang.includes('es')) {
            utterance.lang = 'es-ES';
        }
        
        this.synth.speak(utterance);
        return utterance;
    }

    stop() {
        this.synth.cancel();
    }

    isSpeaking() {
        return this.synth.speaking;
    }
}

class Conceptron {
    constructor(color, shape, tone, name, phrase = '', category = 'basic') {
        this.color = color;
        this.shape = shape;
        this.tone = tone;
        this.name = name;
        this.phrase = phrase || name;
        this.category = category;
    }

    toJSON() {
        return {
            c: this.color,
            f: this.shape,
            t: this.tone,
            n: this.name,
            p: this.phrase,
            cat: this.category
        };
    }
}

// Category organized conceptrons
const CONCEPTRON_CATEGORIES = {
    basic: {
        name: 'Básico',
        icon: '⭐',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Sí', 'Sí', 'basic'),
            new Conceptron('#4ECDC4', 'triangle', 330, 'No', 'No', 'basic'),
            new Conceptron('#FFE66D', 'star', 520, 'Gracias', 'Gracias', 'basic'),
            new Conceptron('#45B7D1', 'heart', 390, 'Por favor', 'Por favor', 'basic'),
            new Conceptron('#AA96DA', 'hexagon', 470, 'Hola', 'Hola', 'basic'),
            new Conceptron('#F38181', 'circle', 550, 'Adiós', 'Adiós', 'basic'),
            new Conceptron('#95E1D3', 'square', 290, 'Más', 'Quiero más', 'basic'),
            new Conceptron('#FF9F43', 'triangle', 410, 'menos', 'Quiero menos', 'basic'),
            new Conceptron('#FCBAD3', 'star', 480, 'Otra vez', 'Otra vez', 'basic'),
            new Conceptron('#A8E6CF', 'heart', 350, 'Vale', 'Vale', 'basic'),
            new Conceptron('#DDA0DD', 'diamond', 360, 'Espera', 'Espera', 'basic'),
            new Conceptron('#87CEEB', 'pentagon', 420, 'Ya', 'Ya está', 'basic')
        ]
    },
    needs: {
        name: 'Necesidades',
        icon: '💚',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Agua', 'Quiero agua', 'needs'),
            new Conceptron('#45B7D1', 'triangle', 330, 'Comida', 'Tengo hambre', 'needs'),
            new Conceptron('#FFE66D', 'square', 520, 'Sed', 'Tengo sed', 'needs'),
            new Conceptron('#4ECDC4', 'hexagon', 470, 'Baño', 'Necesito ir al baño', 'needs'),
            new Conceptron('#AA96DA', 'star', 550, 'Dormir', 'Tengo sueño', 'needs'),
            new Conceptron('#F38181', 'heart', 390, 'Biberón', 'Quiero el biberón', 'needs'),
            new Conceptron('#95E1D3', 'circle', 290, 'Leche', 'Quiero leche', 'needs'),
            new Conceptron('#FF9F43', 'triangle', 410, 'Galletas', 'Quiero galletas', 'needs'),
            new Conceptron('#FCBAD3', 'square', 480, 'Fruta', 'Quiero fruta', 'needs'),
            new Conceptron('#A8E6CF', 'star', 350, 'Pan', 'Quiero pan', 'needs'),
            new Conceptron('#DDA0DD', 'heart', 360, 'Cuenco', 'Mi cuenco está vacío', 'needs'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Más comida', 'Quiero más comida', 'needs')
        ]
    },
    feelings: {
        name: 'Emociones',
        icon: '❤️',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Contento', 'Estoy feliz', 'feelings'),
            new Conceptron('#FFE66D', 'triangle', 330, 'Triste', 'Estoy triste', 'feelings'),
            new Conceptron('#45B7D1', 'square', 520, 'Cansado', 'Estoy cansado', 'feelings'),
            new Conceptron('#4ECDC4', 'hexagon', 470, 'Enfadado', 'Estoy enfadado', 'feelings'),
            new Conceptron('#AA96DA', 'star', 550, 'Asustado', 'Tengo miedo', 'feelings'),
            new Conceptron('#F38181', 'heart', 390, 'Enfermo', 'Estoy enfermo', 'feelings'),
            new Conceptron('#95E1D3', 'circle', 290, 'Calma', 'Estoy tranquilo', 'feelings'),
            new Conceptron('#FF9F43', 'triangle', 410, 'Aburrido', 'Me aburro', 'feelings'),
            new Conceptron('#FCBAD3', 'square', 480, 'Nervioso', 'Estoy nervioso', 'feelings'),
            new Conceptron('#A8E6CF', 'star', 350, 'Sorprendido', 'Estoy sorprendido', 'feelings'),
            new Conceptron('#DDA0DD', 'heart', 360, 'Confundido', 'No entiendo', 'feelings'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Bien', 'Estoy bien', 'feelings')
        ]
    },
    people: {
        name: 'Personas',
        icon: '👥',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Mamá', 'Mamá', 'people'),
            new Conceptron('#4ECDC4', 'triangle', 330, 'Papá', 'Papá', 'people'),
            new Conceptron('#45B7D1', 'square', 520, 'Abuela', 'Abuela', 'people'),
            new Conceptron('#FFE66D', 'hexagon', 470, 'Abuelo', 'Abuelo', 'people'),
            new Conceptron('#AA96DA', 'star', 550, 'Hermano', 'Mi hermano', 'people'),
            new Conceptron('#F38181', 'heart', 390, 'Hermana', 'Mi hermana', 'people'),
            new Conceptron('#95E1D3', 'circle', 290, 'Tío', 'Tío', 'people'),
            new Conceptron('#FF9F43', 'triangle', 410, 'Tía', 'Tía', 'people'),
            new Conceptron('#FCBAD3', 'square', 480, 'Maestro', 'Mi maestro', 'people'),
            new Conceptron('#A8E6CF', 'star', 350, 'Amigo', 'Mi amigo', 'people'),
            new Conceptron('#DDA0DD', 'heart', 360, 'Doctor', 'El doctor', 'people'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Todos', 'Todas las personas', 'people')
        ]
    },
    activities: {
        name: 'Actividades',
        icon: '🎯',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Jugar', 'Quiero jugar', 'activities'),
            new Conceptron('#4ECDC4', 'triangle', 330, 'Pasear', 'Quiero salir a pasear', 'activities'),
            new Conceptron('#45B7D1', 'square', 520, 'Ver TV', 'Quiero ver la televisión', 'activities'),
            new Conceptron('#FFE66D', 'hexagon', 470, 'Música', 'Quiero escuchar música', 'activities'),
            new Conceptron('#AA96DA', 'star', 550, 'Dibujar', 'Quiero dibujar', 'activities'),
            new Conceptron('#F38181', 'heart', 390, 'Leer', 'Quiero leer', 'activities'),
            new Conceptron('#95E1D3', 'circle', 290, 'Baile', 'Quiero bailar', 'activities'),
            new Conceptron('#FF9F43', 'triangle', 410, 'Dentista', 'Voy al dentista', 'activities'),
            new Conceptron('#FCBAD3', 'square', 480, 'Médico', 'Voy al médico', 'activities'),
            new Conceptron('#A8E6CF', 'star', 350, 'Escuela', 'Voy a la escuela', 'activities'),
            new Conceptron('#DDA0DD', 'heart', 360, 'Casa', 'Voy a casa', 'activities'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Fuera', 'Quiero salir', 'activities')
        ]
    },
    pain: {
        name: 'Dolores',
        icon: '💔',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Duele cabeza', 'Me duele la cabeza', 'pain'),
            new Conceptron('#4ECDC4', 'triangle', 330, 'Duele tripa', 'Me duele la tripa', 'pain'),
            new Conceptron('#45B7D1', 'square', 520, 'Duele diente', 'Me duele el diente', 'pain'),
            new Conceptron('#FFE66D', 'hexagon', 470, 'Duele oído', 'Me duele el oído', 'pain'),
            new Conceptron('#AA96DA', 'star', 550, 'Cansado', 'Estoy muy cansado', 'pain'),
            new Conceptron('#F38181', 'heart', 390, 'Mareado', 'Estoy mareado', 'pain'),
            new Conceptron('#95E1D3', 'circle', 290, 'Caliente', 'Tengo calor', 'pain'),
            new Conceptron('#FF9F43', 'triangle', 410, 'Frío', 'Tengo frío', 'pain'),
            new Conceptron('#FCBAD3', 'square', 480, 'Gripe', 'Tengo gripe', 'pain'),
            new Conceptron('#A8E6CF', 'star', 350, 'Alergia', 'Tengo alergia', 'pain'),
            new Conceptron('#DDA0DD', 'heart', 360, 'Náuseas', 'Tengo náuseas', 'pain'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Grave', 'Me siento muy mal', 'pain')
        ]
    },
    phrases: {
        name: 'Frases',
        icon: '💬',
        conceptrons: [
            new Conceptron('#FF6B6B', 'circle', 440, 'Te quiero', 'Te quiero mucho', 'phrases'),
            new Conceptron('#4ECDC4', 'triangle', 330, 'Lo siento', 'Lo siento mucho', 'phrases'),
            new Conceptron('#45B7D1', 'square', 520, 'Perdona', 'Perdona', 'phrases'),
            new Conceptron('#FFE66D', 'hexagon', 470, '¿Qué pasa?', '¿Qué pasa?', 'phrases'),
            new Conceptron('#AA96DA', 'star', 550, 'No entiendo', 'No entiendo', 'phrases'),
            new Conceptron('#F38181', 'heart', 390, '¿Por qué?', '¿Por qué?', 'phrases'),
            new Conceptron('#95E1D3', 'circle', 290, '¿Dónde?', '¿Dónde está?', 'phrases'),
            new Conceptron('#FF9F43', 'triangle', 410, '¿Cuándo?', '¿Cuándo?', 'phrases'),
            new Conceptron('#FCBAD3', 'square', 480, '¿Cómo?', '¿Cómo se hace?', 'phrases'),
            new Conceptron('#A8E6CF', 'star', 350, '¿Quién?', '¿Quién es?', 'phrases'),
            new Conceptron('#DDA0DD', 'heart', 360, '¿Qué es?', '¿Qué es esto?', 'phrases'),
            new Conceptron('#87CEEB', 'diamond', 420, 'Sí, entiendo', 'Sí, entiendo', 'phrases')
        ]
    }
};

class GenomeConverter {
    constructor() {
        this.baseMap = {
            'A': { base: 'A', color: '#FF6B6B', shape: 'circle', tone: 261 },
            'B': { base: 'C', color: '#FF6B6B', shape: 'triangle', tone: 277 },
            'C': { base: 'G', color: '#FF6B6B', shape: 'square', tone: 293 },
            'D': { base: 'T', color: '#4ECDC4', shape: 'circle', tone: 311 },
            'E': { base: 'A', color: '#4ECDC4', shape: 'triangle', tone: 329 },
            'F': { base: 'C', color: '#4ECDC4', shape: 'square', tone: 349 },
            'G': { base: 'G', color: '#45B7D1', shape: 'circle', tone: 369 },
            'H': { base: 'T', color: '#45B7D1', shape: 'triangle', tone: 392 },
            'I': { base: 'A', color: '#45B7D1', shape: 'square', tone: 415 },
            'J': { base: 'C', color: '#FFE66D', shape: 'circle', tone: 440 },
            'K': { base: 'G', color: '#FFE66D', shape: 'triangle', tone: 466 },
            'L': { base: 'T', color: '#FFE66D', shape: 'square', tone: 493 },
            'M': { base: 'A', color: '#95E1D3', shape: 'hexagon', tone: 523 },
            'N': { base: 'C', color: '#95E1D3', shape: 'star', tone: 554 },
            'Ñ': { base: 'G', color: '#95E1D3', shape: 'heart', tone: 587 },
            'O': { base: 'T', color: '#F38181', shape: 'circle', tone: 622 },
            'P': { base: 'A', color: '#F38181', shape: 'triangle', tone: 659 },
            'Q': { base: 'C', color: '#F38181', shape: 'square', tone: 698 },
            'R': { base: 'G', color: '#AA96DA', shape: 'circle', tone: 739 },
            'S': { base: 'T', color: '#AA96DA', shape: 'triangle', tone: 783 },
            'T': { base: 'A', color: '#AA96DA', shape: 'square', tone: 830 },
            'U': { base: 'C', color: '#FCBAD3', shape: 'hexagon', tone: 880 },
            'V': { base: 'G', color: '#FCBAD3', shape: 'star', tone: 932 },
            'W': { base: 'T', color: '#FCBAD3', shape: 'heart', tone: 987 },
            'X': { base: 'A', color: '#FF9F43', shape: 'circle', tone: 1046 },
            'Y': { base: 'C', color: '#FF9F43', shape: 'triangle', tone: 1108 },
            'Z': { base: 'G', color: '#FF9F43', shape: 'square', tone: 1174 },
            ' ': { base: '-', color: '#A8E6CF', shape: 'hexagon', tone: 0 }
        };

        for (let i = 0; i <= 9; i++) {
            this.baseMap[i.toString()] = { 
                base: ['A', 'C', 'G', 'T'][i % 4], 
                color: ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFE66D'][i % 4],
                shape: ['circle', 'triangle', 'square', 'hexagon'][i % 4],
                tone: 220 + (i * 100)
            };
        }
    }

    convert(text) {
        const upper = text.toUpperCase();
        const result = [];
        
        for (const char of upper) {
            if (this.baseMap[char]) {
                result.push({ char, ...this.baseMap[char] });
            } else if (/[a-z]/.test(char)) {
                const upperChar = char.toUpperCase();
                if (this.baseMap[upperChar]) {
                    result.push({ char, ...this.baseMap[upperChar] });
                }
            }
        }
        
        return result;
    }
}

class ConceptronApp {
    constructor() {
        this.audio = new AudioEngine();
        this.voice = new VoiceEngine();
        this.genome = new GenomeConverter();
        this.socket = null;
        this.roomId = null;
        this.currentUser = null;
        this.chain = [];
        this.customConceptrons = [];
        this.users = [];
        this.currentCategory = 'basic';
        this.history = [];

        this.selectedColor = '#FF6B6B';
        this.selectedShape = 'circle';
        this.selectedTone = 440;

        this.init();
    }

    init() {
        this.renderCategories();
        this.renderConceptrons(this.currentCategory);
        this.bindEvents();
        this.initSocket();
        this.initDarkMode();
    }

    createShapeSVG(shape, color) {
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 40 40');
        svg.setAttribute('class', `shape ${shape}`);
        
        let element;
        
        const shapes = {
            circle: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                element.setAttribute('cx', '20');
                element.setAttribute('cy', '20');
                element.setAttribute('r', '16');
            },
            triangle: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '20,4 36,36 4,36');
            },
            square: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
                element.setAttribute('x', '6');
                element.setAttribute('y', '6');
                element.setAttribute('width', '28');
                element.setAttribute('height', '28');
                element.setAttribute('rx', '3');
            },
            hexagon: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '20,2 37,11 37,29 20,38 3,29 3,11');
            },
            star: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '20,2 24,16 38,16 27,25 32,38 20,30 8,38 13,25 2,16 16,16');
            },
            heart: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                element.setAttribute('d', 'M20,36 C6,28 2,16 10,8 C14,4 20,7 20,7 C20,7 26,4 30,8 C38,16 34,28 20,36');
            },
            diamond: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '20,2 38,20 20,38 2,20');
            },
            pentagon: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '20,2 38,15 32,38 8,38 2,15');
            },
            cross: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
                element.setAttribute('points', '17,2 23,2 23,17 38,17 38,23 23,23 23,38 17,38 17,23 2,23 2,17 17,17');
            },
            moon: () => {
                element = document.createElementNS('http://www.w3.org/2000/svg', 'path');
                element.setAttribute('d', 'M20,4 A14,14 0 1,1 20,36 A10,10 0 1,0 20,4');
            }
        };
        
        (shapes[shape] || shapes.circle)();
        element.setAttribute('fill', color);
        svg.appendChild(element);
        
        return svg;
    }

    renderCategories() {
        const container = document.getElementById('categoryTabs');
        if (!container) return;
        
        container.innerHTML = '';
        
        Object.keys(CONCEPTRON_CATEGORIES).forEach(key => {
            const cat = CONCEPTRON_CATEGORIES[key];
            const btn = document.createElement('button');
            btn.className = `category-btn ${key === this.currentCategory ? 'active' : ''}`;
            btn.dataset.category = key;
            btn.innerHTML = `<span class="cat-icon">${cat.icon}</span><span class="cat-name">${cat.name}</span>`;
            btn.onclick = () => this.selectCategory(key);
            container.appendChild(btn);
        });
    }

    selectCategory(category) {
        this.currentCategory = category;
        
        document.querySelectorAll('.category-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.category === category);
        });
        
        this.renderConceptrons(category);
    }

    renderConceptrons(category) {
        const grid = document.getElementById('conceptronGrid');
        grid.innerHTML = '';

        const catData = CONCEPTRON_CATEGORIES[category];
        if (!catData) return;

        const allConceptrons = [...catData.conceptrons, ...this.customConceptrons];

        allConceptrons.forEach((conceptron, index) => {
            const btn = document.createElement('button');
            btn.className = 'conceptron-btn';
            btn.style.backgroundColor = conceptron.color;
            
            const shape = this.createShapeSVG(conceptron.shape, 'rgba(0,0,0,0.35)');
            shape.classList.add('shape');
            btn.appendChild(shape);

            const label = document.createElement('span');
            label.className = 'label';
            label.textContent = conceptron.name;
            btn.appendChild(label);

            const customIndex = index - catData.conceptrons.length;
            if (customIndex >= 0) {
                const deleteBtn = document.createElement('button');
                deleteBtn.className = 'delete-btn';
                deleteBtn.textContent = '×';
                deleteBtn.onclick = (e) => {
                    e.stopPropagation();
                    this.removeCustomConceptron(customIndex);
                };
                btn.appendChild(deleteBtn);
            }

            const addHandler = (e) => {
                e.preventDefault();
                this.addToChain(conceptron);
            };
            btn.onclick = addHandler;
            btn.ontouchstart = addHandler;
            
            grid.appendChild(btn);
        });
    }

    bindEvents() {
        // Room tabs
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.onclick = () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
                btn.classList.add('active');
                document.querySelector(`[data-content="${btn.dataset.tab}"]`).classList.add('active');
            };
        });

        // Create room
        document.getElementById('createRoomBtn').onclick = () => {
            const username = document.getElementById('createUsername').value.trim() || 'Anónimo';
            this.createRoom(username);
        };

        // Join room
        document.getElementById('joinRoomBtn').onclick = () => {
            const username = document.getElementById('joinUsername').value.trim() || 'Anónimo';
            const roomCode = document.getElementById('roomCode').value.trim();
            if (roomCode) {
                this.joinRoom(roomCode, username);
            } else {
                this.showToast('Ingresa el código de sala', 'error');
            }
        };

        // Copy room code
        document.getElementById('copyRoomCode').onclick = () => {
            navigator.clipboard.writeText(this.roomId);
            this.showToast('Código copiado', 'success');
        };

        // Color picker
        document.querySelectorAll('.color-btn').forEach(btn => {
            btn.onclick = () => {
                document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.selectedColor = btn.dataset.color;
            };
        });

        // Shape picker
        document.querySelectorAll('.shape-btn').forEach(btn => {
            btn.onclick = () => {
                document.querySelectorAll('.shape-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.selectedShape = btn.dataset.shape;
            };
        });

        // Tone slider
        const toneSlider = document.getElementById('toneSlider');
        const toneValue = document.getElementById('toneValue');
        toneSlider.oninput = () => {
            this.selectedTone = parseInt(toneSlider.value);
            toneValue.textContent = `${this.selectedTone} Hz`;
        };

        // Preview tone
        document.getElementById('previewTone').onclick = () => {
            this.audio.playTone(this.selectedTone, 0.4);
        };

        // Play scale
        document.getElementById('playScale').onclick = () => {
            this.audio.playScale();
        };

        // Add conceptron
        document.getElementById('addConceptron').onclick = () => {
            const nameInput = document.getElementById('conceptronName');
            const name = nameInput.value.trim() || 'Mi símbolo';
            
            const newConceptron = new Conceptron(
                this.selectedColor,
                this.selectedShape,
                this.selectedTone,
                name,
                name,
                'custom'
            );
            
            if (this.socket && this.roomId) {
                this.socket.emit('addCustomConceptron', newConceptron.toJSON());
            } else {
                this.customConceptrons.push(newConceptron);
            }
            
            this.renderConceptrons(this.currentCategory);
            nameInput.value = '';
            this.showToast('Símbolo añadido', 'success');
        };

        // Clear chain
        document.getElementById('clearChain').onclick = () => {
            if (this.socket && this.roomId) {
                this.socket.emit('clearChain');
            } else {
                this.chain = [];
                this.updateChainDisplay();
            }
        };

        // Speak chain (NEW)
        document.getElementById('speakChain').onclick = () => {
            this.speakChain();
        };

        // Send message to all users
        document.getElementById('sendMessage').onclick = () => {
            this.sendMessage();
        };

        // Play chain
        document.getElementById('playChain').onclick = () => {
            if (this.socket && this.roomId) {
                this.socket.emit('playChain');
            } else {
                this.playChain();
            }
        };

        // Stop playback
        document.getElementById('stopPlayback').onclick = () => {
            this.audio.stop();
            this.voice.stop();
            document.getElementById('stopPlayback').disabled = true;
            document.getElementById('chainDisplay').classList.remove('playing');
        };

        // Genome generator
        document.getElementById('generateGenome').onclick = () => {
            const input = document.getElementById('genomeInput');
            const text = input.value.trim();
            if (text) {
                this.generateGenome(text);
            }
        };

        document.getElementById('genomeInput').onkeypress = (e) => {
            if (e.key === 'Enter') {
                document.getElementById('generateGenome').click();
            }
        };

        // Export/Import
        document.getElementById('exportConceptrons').onclick = () => {
            this.exportConceptrons();
        };

        document.getElementById('importConceptrons').onclick = () => {
            document.getElementById('importFile').click();
        };

        document.getElementById('importFile').onchange = (e) => {
            this.importConceptrons(e.target.files[0]);
        };

        // Dark mode
        document.getElementById('darkModeToggle').onclick = () => {
            this.toggleDarkMode();
        };

        // Voice toggle
        document.getElementById('voiceToggle').onclick = () => {
            this.toggleVoice();
        };
    }

    initSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            console.log('Connected to server');
        });

        this.socket.on('roomCreated', (data) => {
            this.roomId = data.roomId;
            this.currentUser = data.user;
            this.showRoomPanel(data);
            this.showToast(`Sala creada: ${data.roomId}`, 'success');
        });

        this.socket.on('roomState', (data) => {
            this.roomId = data.roomId;
            this.showRoomPanel(data);
        });

        this.socket.on('userJoined', (user) => {
            this.users.push(user);
            this.updateUsersList();
            this.showToast(`${user.username} se unió`, 'success');
        });

        this.socket.on('userLeft', (data) => {
            this.users = this.users.filter(u => u.id !== data.userId);
            this.updateUsersList();
        });

        this.socket.on('chainUpdated', (data) => {
            this.chain = data.chain;
            this.updateChainDisplay();
            
            if (data.addedItem) {
                this.audio.playTone(data.addedItem.tone || 440, 0.3);
                if (this.voiceEnabled) {
                    this.voice.speak(data.addedItem.phrase || data.addedItem.name || data.addedItem.n || '');
                }
            }
        });

        this.socket.on('chainCleared', (data) => {
            this.chain = [];
            this.updateChainDisplay();
        });

        this.socket.on('customConceptronsUpdated', (data) => {
            this.customConceptrons = data.customConceptrons.map(c => 
                new Conceptron(c.color, c.shape, c.tone, c.name, c.phrase, c.category)
            );
            this.renderConceptrons(this.currentCategory);
            if (data.added) {
                this.showToast(`${data.added.createdBy} añadió: ${data.added.name}`, 'success');
            }
        });

        this.socket.on('playChainSync', (data) => {
            this.playChain();
        });

        this.socket.on('speakChainSync', (data) => {
            this.speakChain();
        });

        this.socket.on('messageReceived', (data) => {
            this.receiveMessage(data);
        });
    }

    showRoomPanel(state) {
        document.getElementById('roomInfo').style.display = 'block';
        document.getElementById('displayRoomCode').textContent = this.roomId;
        
        this.users = state.users;
        this.updateUsersList();
        
        if (state.chain) {
            this.chain = state.chain;
            this.updateChainDisplay();
        }
        
        if (state.customConceptrons) {
            this.customConceptrons = state.customConceptrons.map(c => 
                new Conceptron(c.color, c.shape, c.tone, c.name, c.phrase, c.category)
            );
            this.renderConceptrons(this.currentCategory);
        }
        
        document.getElementById('mainContent').style.display = 'flex';
    }

    updateUsersList() {
        const list = document.getElementById('usersList');
        list.innerHTML = this.users.map(u => `
            <span class="user-badge">
                <span class="dot" style="background: ${u.color}"></span>
                ${u.username}
            </span>
        `).join('');
        
        document.getElementById('connectedUsers').textContent = this.users.length;
    }

    createRoom(username) {
        this.socket.emit('createRoom', { username });
    }

    joinRoom(roomId, username) {
        this.socket.emit('joinRoom', { roomId, username });
    }

    initDarkMode() {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            this.updateDarkModeIcons();
        }
        
        this.voiceEnabled = localStorage.getItem('voiceEnabled') !== 'false';
        this.updateVoiceIcon();
    }

    toggleDarkMode() {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        
        if (isDark) {
            document.documentElement.removeAttribute('data-theme');
            localStorage.setItem('theme', 'light');
        } else {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('theme', 'dark');
        }
        
        this.updateDarkModeIcons();
    }

    updateDarkModeIcons() {
        const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
        document.querySelector('.icon-moon').style.display = isDark ? 'none' : 'inline';
        document.querySelector('.icon-sun').style.display = isDark ? 'inline' : 'none';
    }

    toggleVoice() {
        this.voiceEnabled = !this.voiceEnabled;
        localStorage.setItem('voiceEnabled', this.voiceEnabled);
        this.updateVoiceIcon();
        this.showToast(this.voiceEnabled ? 'Voz activada' : 'Voz desactivada', 'success');
    }

    updateVoiceIcon() {
        const btn = document.getElementById('voiceToggle');
        if (btn) {
            btn.innerHTML = this.voiceEnabled ? '🔊' : '🔇';
            btn.title = this.voiceEnabled ? 'Desactivar voz' : 'Activar voz';
        }
    }

    addToChain(conceptron) {
        if (this.chain.length >= 20) {
            this.showToast('Máximo 20 símbolos', 'error');
            return;
        }
        
        if (this.socket && this.roomId) {
            this.socket.emit('addToChain', conceptron.toJSON());
        } else {
            this.chain.push({
                ...conceptron.toJSON(),
                id: Date.now(),
                username: 'Tú'
            });
            this.updateChainDisplay();
            this.audio.playTone(conceptron.tone, 0.3);
            if (this.voiceEnabled) {
                this.voice.speak(conceptron.phrase);
            }
        }
    }

    updateChainDisplay() {
        const display = document.getElementById('chainDisplay');
        
        if (this.chain.length === 0) {
            display.innerHTML = '<p class="placeholder-text">Toca los símbolos para crear tu mensaje</p>';
            document.getElementById('playChain').disabled = true;
            document.getElementById('speakChain').disabled = true;
            document.getElementById('sendMessage').disabled = true;
        } else {
            display.innerHTML = '';
            this.chain.forEach((item, index) => {
                const itemDiv = document.createElement('div');
                itemDiv.className = 'chain-item';
                itemDiv.style.backgroundColor = item.color || item.c;
                
                const shape = this.createShapeSVG(item.shape || item.f, 'rgba(0,0,0,0.4)');
                shape.classList.add('shape');
                itemDiv.appendChild(shape);
                
                const name = document.createElement('span');
                name.className = 'name';
                name.textContent = item.name || item.n;
                itemDiv.appendChild(name);

                if (item.username) {
                    const userBadge = document.createElement('span');
                    userBadge.className = 'user-badge-mini';
                    userBadge.style.backgroundColor = item.userColor || '#6C63FF';
                    userBadge.textContent = item.username.charAt(0).toUpperCase();
                    itemDiv.appendChild(userBadge);
                }
                
                itemDiv.onclick = () => {
                    if (this.socket && this.roomId) {
                        this.socket.emit('removeFromChain', item.id);
                    } else {
                        this.chain.splice(index, 1);
                        this.updateChainDisplay();
                    }
                };
                
                display.appendChild(itemDiv);
            });
            
            document.getElementById('playChain').disabled = false;
            document.getElementById('speakChain').disabled = false;
            document.getElementById('sendMessage').disabled = false;
        }
        
        document.getElementById('chainLength').textContent = this.chain.length;
    }

    getChainText() {
        return this.chain.map(item => item.phrase || item.p || item.name || item.n).join(' ');
    }

    speakChain() {
        const text = this.getChainText();
        if (text) {
            this.voice.speak(text);
            document.getElementById('stopPlayback').disabled = false;
            
            this.voice.synth.onend = () => {
                document.getElementById('stopPlayback').disabled = true;
            };
        }
    }

    async playChain() {
        if (this.chain.length === 0) return;
        
        document.getElementById('playChain').disabled = true;
        document.getElementById('stopPlayback').disabled = false;
        document.getElementById('chainDisplay').classList.add('playing');
        
        const chainData = this.chain.map(item => ({
            color: item.color || item.c,
            shape: item.shape || item.f,
            tone: item.tone || item.t,
            name: item.name || item.n,
            phrase: item.phrase || item.p
        }));
        
        await this.audio.playSequence(chainData, (conceptron, index) => {
            const items = document.querySelectorAll('.chain-item');
            items.forEach((item, i) => {
                if (i === index) {
                    item.classList.add('playing');
                } else {
                    item.style.opacity = '0.4';
                }
            });
            
            if (this.voiceEnabled && conceptron.phrase) {
                this.voice.speak(conceptron.phrase);
            }
            
            setTimeout(() => {
                items.forEach(item => {
                    item.classList.remove('playing');
                    item.style.opacity = '1';
                });
            }, 550);
        });
        
        document.getElementById('playChain').disabled = false;
        document.getElementById('stopPlayback').disabled = true;
        document.getElementById('chainDisplay').classList.remove('playing');
    }

    removeCustomConceptron(index) {
        const conceptron = this.customConceptrons[index];
        
        if (this.socket && this.roomId) {
            this.socket.emit('removeCustomConceptron', conceptron.id);
        } else {
            this.customConceptrons.splice(index, 1);
            this.renderConceptrons(this.currentCategory);
        }
    }

    generateGenome(text) {
        const result = document.getElementById('genomeResult');
        result.innerHTML = '';
        
        const genomeData = this.genome.convert(text);
        
        genomeData.forEach((item, index) => {
            const symbol = document.createElement('div');
            symbol.className = 'genome-symbol';
            symbol.style.animationDelay = `${index * 0.08}s`;
            
            const shape = this.createShapeSVG(item.shape, item.color);
            shape.classList.add('shape');
            symbol.appendChild(shape);
            
            const base = document.createElement('span');
            base.className = 'base';
            base.textContent = item.base;
            symbol.appendChild(base);
            
            result.appendChild(symbol);
        });
    }

    exportConceptrons() {
        const data = {
            version: '3.0',
            exportDate: new Date().toISOString(),
            customConceptrons: this.customConceptrons.map(c => c.toJSON())
        };
        
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `conceptrones-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        
        this.showToast('Símbolos exportados', 'success');
    }

    importConceptrons(file) {
        if (!file) return;
        
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const data = JSON.parse(e.target.result);
                
                if (data.customConceptrons && Array.isArray(data.customConceptrons)) {
                    const imported = data.customConceptrons.map(c => 
                        new Conceptron(c.c, c.f, c.t, c.n, c.p, c.cat)
                    );
                    
                    this.customConceptrons = [...this.customConceptrons, ...imported];
                    this.renderConceptrons(this.currentCategory);
                    this.showToast(`${imported.length} símbolos importados`, 'success');
                }
            } catch (err) {
                this.showToast('Error al importar', 'error');
            }
        };
        reader.readAsText(file);
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        container.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    sendMessage() {
        if (this.chain.length === 0) return;
        
        const messageData = {
            chain: this.chain,
            sender: this.currentUser?.username || 'Tú',
            senderColor: this.currentUser?.color || '#6C63FF',
            timestamp: Date.now()
        };
        
        if (this.socket && this.roomId) {
            this.socket.emit('sendMessage', messageData);
            this.showToast('Mensaje enviado', 'success');
            
            if (this.voiceEnabled) {
                this.voice.speak('Mensaje enviado');
            }
        }
        
        this.chain = [];
        this.updateChainDisplay();
    }

    receiveMessage(data) {
        const messagesList = document.getElementById('messagesList');
        
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message-item';
        messageDiv.style.borderLeftColor = data.senderColor;
        
        const senderSpan = document.createElement('span');
        senderSpan.className = 'sender';
        senderSpan.style.color = data.senderColor;
        senderSpan.textContent = data.sender;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'content';
        
        data.chain.forEach(item => {
            const shape = this.createShapeSVG(item.shape || item.f, item.color || item.c);
            shape.classList.add('shape');
            contentDiv.appendChild(shape);
        });
        
        const textSpan = document.createElement('span');
        textSpan.className = 'text';
        textSpan.textContent = data.chain.map(i => i.phrase || i.p || i.name || i.n).join(' ');
        contentDiv.appendChild(textSpan);
        
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'actions';
        
        const playBtn = document.createElement('button');
        playBtn.className = 'play-btn';
        playBtn.textContent = '▶';
        playBtn.onclick = () => {
            data.chain.forEach(item => {
                this.audio.playTone(item.tone || item.t || 440, 0.4);
            });
            if (this.voiceEnabled) {
                const text = data.chain.map(i => i.phrase || i.p || i.name || i.n).join(' ');
                this.voice.speak(text);
            }
        };
        
        actionsDiv.appendChild(playBtn);
        
        messageDiv.appendChild(senderSpan);
        messageDiv.appendChild(contentDiv);
        messageDiv.appendChild(actionsDiv);
        
        messagesList.insertBefore(messageDiv, messagesList.firstChild);
        
        this.showToast(`${data.sender} envió un mensaje`, 'success');
        
        if (this.voiceEnabled) {
            const text = data.chain.map(i => i.phrase || i.p || i.name || i.n).join(' ');
            this.voice.speak(`${data.sender} dice: ${text}`);
        }
    }
}

document.addEventListener('DOMContentLoaded', () => {
    window.app = new ConceptronApp();
});
